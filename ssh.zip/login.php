<?php session_start(); /* Starts the session */
	
	/* Check Login form submitted */	
	if(isset($_POST['submit'])){
		/* Define username and associated password array */
		/* dito ka maglalagay ng credentials ng login yung nasa unahan lagi ayun yung username 'iephraf' then yung pass yung => 'iephxuns' at pwede kapa mag dagdag ng another credentials ganito
		example:
		$logins = array('iephraf' => 'iephxuns','usernamenabago' => 'passwordngbago');
	maglalagay kalang ng kuwit then lagay yung bagong credentials okay gets */
	/* ito yung credentials ������ */
		$logins = array('iephraf' => 'iephxuns');
		
		/* Check and assign submitted Username and Password to new variable */
		$Username = isset($_POST['username']) ? $_POST['username'] : '';
		$Password = isset($_POST['password']) ? $_POST['password'] : '';
		
		/* Check Username and Password existence in defined array */		
		if (isset($logins[$Username]) && $logins[$Username] == $Password){
			/* Success: Set session variables and redirect to Protected page  */
			$_SESSION['UserData']['username']=$logins[$Username];
			header("location:index.php");
			exit;
		} else {
			/*Unsuccessful attempt: Set error message */
			$msg="<span style='color:red'>Invalid Login Details</span>";
		}
	}
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>IEPHXUNS SSH</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="/logo.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/css/util.css">
	<link rel="stylesheet" type="text/css" href="/assets/login/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('/back.jpeg');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post" name="Login_Form">
					<center><img src="/logo.png" height="100" width="auto"></center>

					<span class="login100-form-title p-b-34 p-t-27">
						Log in
					</span>
<?php if(isset($msg)){?>
     <center> <?php echo $msg;?></center>
    
    <?php } ?>
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
						<label class="label-checkbox100" for="ckb1">
							Remember me
						</label>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit">
							Login
						</button>
					</div>
<br><br>
					
					<style>
h1.hidden {
  display: none;
}
</style>
					<h1 class="WAG NA WAG MONG TATANGGALIN YUNG CREDITS MAHIYA KA NAMAN"></h1>
	<center><font color="#0000ff">Credits &hearts;IEPH-Raf</font>
	<br><br>
	Join to our forum
	<br>
	<a href="https://www.iephxuns.com"><font color="#fff">JOIN NOW</a></font>
	</center>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="/assets/login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/bootstrap/js/popper.js"></script>
	<script src="/assets/login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/daterangepicker/moment.min.js"></script>
	<script src="/assets/login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/js/main.js"></script>

</body>
</html>