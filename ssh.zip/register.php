<?php include('server.php') ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>IEPHXUNS SSH</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="/logo.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="/assets/login/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="/assets/login/css/util.css">
	<link rel="stylesheet" type="text/css" href="/assets/login/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('/back.jpeg');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post" action="register.php">
					<center><img src="/logo.png" height="100" width="auto"></center>

					<span class="login100-form-title p-b-34 p-t-27">
						Register
					</span>
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="username" value="<?php echo $username; ?>" placeholder="Username">
						<span class="focus-input100" data-placeholder="&#xf207" style="color:black;"></span>
					</div>
						
						<div class="wrap-input100 validate-input" data-validate = "Enter Email">
						<input class="input100" type="text" name="email" value="<?php echo $email; ?>" placeholder="Email">
						<span class="focus-input100" data-placeholder="&#9993" style="color:black;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="password_1" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf191" style="color:black;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Confirm password">
						<input class="input100" type="password" name="password_2" placeholder="Confirm Password">
						<span class="focus-input100" data-placeholder="&#xf191" style="color:black;"></span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="reg_user">
							Register
						</button>
					</div>
						<br>
						<p>
			<center><font color="#fff">Already member? </font><a href="login.php"><font color="#ff0000">Sign in</font></a></center>
		</p>
<br><br>
					
					<style>
h1.hidden {
  display: none;
}
</style>
					<h1 class="WAG NA WAG MONG TATANGGALIN YUNG CREDITS MAHIYA KA NAMAN"></h1>
	<center><font color="#0000ff">Credits &hearts;IEPH-Raf</font>
	<br><br>
	Join to our forum
	<br>
	<a href="https://www.iephxuns.com"><font color="#fff">JOIN NOW</a></font>
	</center>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="/assets/login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/bootstrap/js/popper.js"></script>
	<script src="/assets/login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/daterangepicker/moment.min.js"></script>
	<script src="/assets/login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="/assets/login/js/main.js"></script>

</body>
</html>