<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}


include 'server.php';

	
for ($row = 1; $row < 101; $row++)
	{
	if ( $_POST['server'] == $server_lists_array[$row][1] )
		{
		$hosts= $server_lists_array[$row][2];
		$root_pass= $server_lists_array[$row][3];
		$expiration= $server_lists_array[$row][4];
		break;
		}
	}
$error = false;
if (isset($_POST['user']))
{
	
		$uname = trim($_POST['user']);
		$uname = strip_tags($uname);
		$uname = htmlspecialchars($uname);
		$ieph = '-iephxuns';
        $name = $uname . $ieph;
		$password1 = trim($_POST['password']);
		$password1 = strip_tags($password1);
		$password1 = htmlspecialchars($password1);
		$cpassword = $_POST['confirmpassword'];
		$cpassword = strip_tags($cpassword);
		$cpassword = htmlspecialchars($cpassword);
		$password1 = $_POST['password'];
		$nDays = $expiration;
		$datess = date('m/d/y', strtotime('+'.$nDays.' days'));
		$password = escapeshellarg( crypt($password1) );
		
		if (empty($uname)) 
			{
				$error = true;
				$nameError = "Please Enter A Username.";
			}
		else if (strlen($uname) < 3) 
			{
				$error = true;
				$nameError = "Username Must Have Atleast 3 Characters.";
			}
		if (empty($password1))
			{
				$error = true;
				$passError = "Please Enter A Password.";
			} 
		else if(strlen($password1) < 3) 
			{
				$error = true;
				$passError = "Password Must Have Atleast 3 Characters.";
			}
		if($password1 != $cpassword)
			{
				$error = true;
				$cpaseror = "Password Didn't Match.";
			}  
		if( !$error ) 
			{
				date_default_timezone_set('UTC');
				date_default_timezone_set("Asia/Manila"); 
				$my_date = date("Y-m-d H:i:s"); 
				$connection = ssh2_connect($hosts, 22);
				if (ssh2_auth_password($connection, 'root', $root_pass)) 
					{
						$show = true;	 
						ssh2_exec($connection, "useradd $name -m -p $password -e $datess -d  /tmp/$name -s /bin/false");
						$succ = 'Added Succesfully';
						if ($result) 
							{
								$errTyp = "success";
								$errMSG = "Successfully registered, you may Check your credentials";
								$uname = '';
								$password = '';
								$cpassword = '';
							} 
						else 
							{
								$errTyp = "danger";
								$errMSG = "Something went wrong, try again later..."; 
							} 
					} 
				else 
					{
						die('Connection Failed...');
					}	
			}   
	} 

?>

<?php 
include ('header.php');
?>
	

			<!-- start banner Area -->
			<section class="banner-area" id="home">
				<div class="container">
					<div class="row fullscreen d-flex align-items-center">
						<div class="banner-content col-lg-7 col-md-6 justify-content-center ">
						<br><br><br>
							<h6 class="text-uppercase">WELCOME TO</h6>
							<h1>
								IEPHXUNS SSH			
							</h1>
							<p class="text-white">
								The best ssh provider
							</p>
							<br><br>
						
				</div>
			</section>
			<!-- End banner Area -->
			
			<!-- LOGIN MESSAGE -->
			<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
			
			<!-- Start work-process Area -->
			<section class="work-process-area pt-120">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-60 col-lg-7">
							<div class="title text-center">
								<h1 class="mb-10">Our Services</h1>
								<p>We provide the fastest ssh you want</p>
							</div>
						</div>
					</div>	
					<div class="total-work-process d-flex flex-wrap justify-content-around align-items-center">
						<div class="single-work-process">
							<div class="work-icon-box">
								<span class="lnr lnr-funnel"></span>
							</div>
							<h4 class="caption">Unlimited bandwidth</h4>
						</div>
						<div class="work-arrow">
							<img src="img/arrow.png" alt="">
						</div>
						<div class="single-work-process">
							<div class="work-icon-box">
								<span class="lnr lnr-layers"></span>
							</div>
							<h4 class="caption">Fast Data Transfer</h4>
						</div>
						<div class="work-arrow">
							<img src="img/arrow.png" alt="">
						</div>
						<div class="single-work-process">
							<div class="work-icon-box">
								<span class="lnr lnr-lock"></span>
							</div>
							<h4 class="caption">Hide Your Real IP</h4>
						</div>
						<div class="work-arrow">
							<img src="img/arrow.png" alt="">
						</div>
						<div class="single-work-process">
							<div class="work-icon-box">
								<span class="lnr lnr-smile"></span>
							</div>
							<h4 class="caption">Security Solutions</h4>
						</div>											
					<div class="row">
						<div class="col"></div>
					</div>
				</div>	
			</section>
			<!-- End work-process Area -->
						<br><br><br>

			<!-- Start discount-section Area -->
			<section class="discount-section-area relative section-gap">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row align-items-center justify-content-between no-gutters">
						<div class="col-lg-6 discount-left">
							<h1 class="text-white">CREATE SSH NOW</h1>
							<p class="text-white">
								SERVER: SG,US,INDIA
							</p>
							
						</div>
						<div class="col-lg-5 discount-right">
						
							 <div class="form-group">
							<div class="alert-danger">
								<span class="text-light"><?php echo $nameError; ?></span>
							</div>					
							<div class="alert-danger">
								<span class="text-light"><?php echo $passError; ?></span>
							</div>
							<div class="alert-danger">
								<span class="text-light"><?php echo $cpaseror; ?></span>
							</div>
						</div>
						
		                    <form method="post" class="booking-form" id="myForm" action="#">
		                        <div class="row">
		                        
		   <center><div class="input-group-icon mt-10">
										<div class="icon"><i class="fa fa-cloud" aria-hidden="true"></i></div>
										<div class="form-select" id="default-select">
											<select name="server">
											 <i class="fa fa-globe" style="color:red;"></i><option disabled selected value>Select Server</option>
											label="IEPHXUNS SERVER">
												 <?php
                                            for ($row = 1; $row < 101; $row++)
                                            {
                                                if ( !empty($server_lists_array[$row][1]))
                                                {
                                                    echo '<option>'; echo $server_lists_array[$row][1]; echo '</option>';
                                                }
                                                else
                                                {
                                                    break;
                                                }                                                       
                                            }
                                            ?>
											</select>
										</div>
									</div>
									</div>
</center>
		   
		                            <div class="col-lg-12 d-flex flex-column">
		                                <input name="user" placeholder="Enter Username" value="<?php echo $uname ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" class="form-control mt-20" required="" type="text">
		                            </div>
		                             <div class="col-lg-12 d-flex flex-column">
		                                <input name="password" value="<?php echo $password1 ?>" placeholder="Enter Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" class="form-control mt-20" required="" type="text">
		                            </div>
		                             <div class="col-lg-12 d-flex flex-column">
		                                <input name="confirmpassword" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" class="form-control mt-20" required="" type="text">
		                            </div>

		                            <div class="col-lg-12 d-flex justify-content-end send-btn">
		                                <button class="genric-btn primary mt-20 text-uppercase " value="Register">CREATE</button>
		                            </div>
		                                <?php
						
						if($show == true) {
						echo '<div class="alert alert-info">
';

							echo '<center>'; echo '<font color="#0000FF">'; echo 'ACCOUNT INFO'; echo '</center>';echo '</font>';
													
echo '<center>'; echo '<font color="#000">';echo 'WARNING<br><i style="font-size:15px" class="fa">&#xf071;</i>
NO TORRENT<br><i style="font-size:15px" class="fa">&#xf071;</i>
NO DDOS<br><i style="font-size:15px" class="fa">&#xf071;</i>
NO MULTI LOGIN'; echo '</font>'; echo '<br><br>';
						 
						
						 echo 'Host:';  echo $hosts;  
										 echo 'Username:';  echo $username;  
										 echo 'Password:';  echo $password1;  
										 echo 'SSH Port:';  echo $port_ssh;  
										 echo 'Dropbear Port:';  echo $port_dropbear;  
										 echo 'SSL Port:';  echo $port_ssl;  
										 echo 'Squid Port:';  echo $port_squid;  
										 echo 'OpenVPN Config:'; echo '<a href="http://';echo $hosts; echo "/"; echo "client.ovpn"; echo'">download config</a>';  
										 echo 'Expiration Date:'; echo $datess;
						 
						
						}
						?>
		                        </div>
		                    </form>
						</div>
					</div>
				</div>	
			</section>
			<!-- End discount-section Area -->
			
			
						
				<br><br><br>

			
			<!-- End footer Area -->	

<style>
.footer {
   position: bottom;
   left: 0;
   bottom: 0;
   width: 100%;
   height: auto;
   background-color: black;
   color: white;
   text-align: center;
}
h1.hidden {
  display: none;
}
</style>
					<h1 class="WAG NA WAG MONG TATANGGALIN YUNG CREDITS MAHIYA KA NAMAN"></h1>
   <div class="footer">
   <br>
 &copy; IEPHXUN SSH<br>
 JOIN NOW TO OUR FORUM<br>
 <a href="https://www.iephxuns.com">JOIN</a>
 <br>
Credits: IEPH-RAF
 <br><br>
</div>
   
			<script src="/assets/iephraf/js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="/assets/iephraf/js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="/assets/iephraf/js/hoverIntent.js"></script>
			<script src="/assets/iephraf/js/superfish.min.js"></script>	
			<script src="/assets/iephraf/js/mn-accordion.js"></script>
			<script src="/assets/iephraf/js/jquery.ajaxchimp.min.js"></script>
			<script src="/assets/iephraf/js/jquery.magnific-popup.min.js"></script>	
			<script src="/assets/iephraf/js/owl.carousel.min.js"></script>						
			<script src="/assets/iephraf/js/jquery.nice-select.min.js"></script>	
    		<script src="/assets/iephraf/js/jquery.circlechart.js"></script>								
			<script src="/assets/iephraf/js/mail-script.js"></script>	
			<script src="/assets/iephraf/js/main.js"></script>	
		</body>
	</html>