<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="logo.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>IEPHXUNS SSH</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="/assets/iephraf/css/linearicons.css">
			<link rel="stylesheet" href="/assets/iephraf/css/font-awesome.min.css">
			<link rel="stylesheet" href="/assets/iephraf/css/bootstrap.css">
			<link rel="stylesheet" href="/assets/iephraf/css/magnific-popup.css">
			<link rel="stylesheet" href="/assets/iephraf/css/nice-select.css">							
			<link rel="stylesheet" href="/assets/iephraf/css/animate.min.css">
			<link rel="stylesheet" href="/assets/iephraf/css/owl.carousel.css">
			<link rel="stylesheet" href="/assets/iephraf/css/main.css">
		</head>
		<body>	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  				
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				<a href="">Our forum IEPHXUNS</a>
				  				<a href="https://www.iephxuns.com" target="_blank">JOIN NOW!</a>				
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index.html"><img src="/logo.png" height="50" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="/index.php">Home</a></li>
				          <li><a href="https://www.iephxuns.com" target="_blank">Forum</a></li>
				          <li><a href="index.php?logout='1'">Logout</a></li>
				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->